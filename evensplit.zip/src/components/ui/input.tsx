import * as React from "react";

import { cn } from "@/lib/utils";

export const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(
  ({ className, ...props }, ref) => {
    return (
      <input
        ref={ref}
        className={cn(
          "flex h-10 w-full rounded-md border border-zinc-300 bg-white px-3 py-2 text-sm outline-none ring-offset-background placeholder:text-zinc-400 focus-visible:ring-2 focus-visible:ring-emerald-500",
          className,
        )}
        {...props}
      />
    );
  },
);

Input.displayName = "Input";
